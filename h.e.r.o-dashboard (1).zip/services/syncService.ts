
import { School, Student } from "../types";

export const parseCSV = (csvText: string) => {
  const lines = csvText.split('\n').filter(line => line.trim() !== '');
  const headers = lines[0].split(',');
  
  return lines.slice(1).map(line => {
    const values = line.split(',');
    const obj: any = {};
    headers.forEach((header, i) => {
      const key = header.trim();
      let value: any = values[i]?.trim();
      
      // Auto-convert numbers
      if (!isNaN(value) && value !== '') {
        value = Number(value);
      }
      obj[key] = value;
    });
    return obj;
  });
};

export const fetchGoogleSheetData = async (url: string) => {
  try {
    // Ensure the URL is in CSV format
    let csvUrl = url;
    if (url.includes('/edit')) {
      csvUrl = url.replace(/\/edit.*$/, '/export?format=csv');
    }
    
    const response = await fetch(csvUrl);
    if (!response.ok) throw new Error('Gagal mengambil data dari Google Sheets');
    const text = await response.text();
    return parseCSV(text);
  } catch (error) {
    console.error("Sync Error:", error);
    throw error;
  }
};
