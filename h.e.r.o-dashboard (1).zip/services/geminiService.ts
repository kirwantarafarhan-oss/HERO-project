
import { GoogleGenAI, Type } from "@google/genai";
import { School } from "../types";

const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// Service to get dashboard insights with robust error handling and retry logic
export const getDashboardInsights = async (schools: School[], retryCount = 0): Promise<string[]> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  // Only analyze schools that have revenue to save context/tokens
  const activeSchools = schools.filter(s => s.revenue > 0);
  if (activeSchools.length === 0) {
    return ["Kompetisi H.E.R.O baru saja dimulai!", "Belum ada transaksi masuk untuk dianalisis.", "Segera upload data di Data Master untuk melihat performa sekolah."];
  }

  const schoolDataString = activeSchools
    .sort((a, b) => b.revenue - a.revenue)
    .slice(0, 5) // Analyze top 5 for efficiency
    .map(s => `${s.name}: Rp${s.revenue.toLocaleString()} (${s.salesCount} sales)`)
    .join('\n');
  
  const prompt = `
    Anda adalah analis bisnis profesional untuk kompetisi H.E.R.O (Highschool Entrepreneur Race OSIS).
    Berikut data penjualan top sekolah:
    ${schoolDataString}
    
    Tolong berikan 3 poin analisis strategis dalam Bahasa Indonesia:
    1. Analisis posisi pemimpin dan jarak persaingan.
    2. Satu insight tentang produktivitas (sales vs revenue).
    3. Rekomendasi taktis untuk meningkatkan omset bagi sekolah lainnya.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            insights: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
          },
          required: ['insights'],
        },
      }
    });

    const data = JSON.parse(response.text || '{"insights": []}');
    return data.insights.length > 0 ? data.insights : ["Data tersedia, namun analisis AI tidak menghasilkan poin.", "Silakan coba refresh kembali."];
  } catch (error: any) {
    console.error("Gemini API Error:", error);

    // Handle 429 Resource Exhausted with exponential backoff
    if (error?.message?.includes('429') || error?.status === 429) {
      if (retryCount < 2) {
        const waitTime = Math.pow(2, retryCount) * 2000;
        console.warn(`Quota limit hit. Retrying in ${waitTime}ms...`);
        await sleep(waitTime);
        return getDashboardInsights(schools, retryCount + 1);
      }
      return [
        "Kuota AI Gratis telah mencapai batas (Limit 429).",
        "Sistem akan tersedia kembali secara otomatis dalam beberapa menit.",
        "Anda tetap bisa memantau angka penjualan secara manual di tabel klasemen."
      ];
    }

    return [
      "Gagal terhubung dengan layanan Analisis AI.",
      "Pastikan koneksi internet stabil atau cek API Key Anda.",
      "Data angka tetap akurat meskipun analisis AI sedang offline."
    ];
  }
};
