
export interface Product {
  name: string;
  sold: number;
}

export interface Student {
  id: string;
  name: string;
  schoolName: string;
  transactions: number;
  revenue: number;
}

export interface SchoolStudent {
  name: string;
  phoneNumber: string;
  className: string;
  transactions: number;
}

export interface CarrierStats {
  telkomsel: number;
  indosat: number;
  xl: number;
}

export interface DailySale {
  id: string;
  date: string;
  idDigipos: string;
  schoolName: string;
  msisdn: string;
  customerName: string;
  productName: string;
  qty: number;
  price: number;
  revenue: number;
}

export interface School {
  id: string;
  idDigipos?: string;
  name: string;
  revenue: number;
  prevRevenue: number;
  salesCount: number;
  lastSale: string;
  trend: 'up' | 'down' | 'stable';
  region: string;
  topProducts: Product[];
  totalTransactions: number;
  studentCount: number;
  topStudentName: string;
  teacherCount: number;
  topClass: string;
  topActiveStudents: SchoolStudent[];
  carrierStats: CarrierStats;
  dailySales: DailySale[]; // New field for detailed history
}

export interface DashboardStats {
  totalRevenue: number;
  totalSales: number;
  topSchool: string;
  averageRevenue: number;
}

export interface SalesRecord {
  date: string;
  amount: number;
}
