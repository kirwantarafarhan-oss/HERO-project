
import React, { useState, useEffect, useMemo } from 'react';
import { 
  LayoutDashboard, School as SchoolIcon, TrendingUp, DollarSign, 
  Users, RefreshCw, Trophy, Sparkles, Clock, Settings2, Rocket, Calendar, 
  Crown, ChevronRight, BrainCircuit, AlertCircle
} from 'lucide-react';
import { SCHOOLS_DATA, DAILY_CHART, WEEKLY_CHART, MONTHLY_CHART } from './constants';
import { School, Student } from './types';
import SchoolDetailModal from './components/SchoolDetailModal';
import DataManagement from './components/DataManagement';
import { getDashboardInsights } from './services/geminiService';
import { fetchGoogleSheetData } from './services/syncService';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'management'>('dashboard');
  const [schools, setSchools] = useState<School[]>(() => {
    const saved = localStorage.getItem('school_sales_data');
    return saved ? JSON.parse(saved) : SCHOOLS_DATA;
  });
  
  const [dailyData, setDailyData] = useState(DAILY_CHART);
  const [weeklyData, setWeeklyData] = useState(WEEKLY_CHART);
  const [monthlyData, setMonthlyData] = useState(MONTHLY_CHART);

  const [headerLabels, setHeaderLabels] = useState(() => {
    const saved = localStorage.getItem('dashboard_header_labels');
    return saved ? JSON.parse(saved) : {
      schoolName: 'Nama Sekolah',
      studentCount: 'Siswa (Angka)',
      topStudent: 'Siswa Terbaik (Teks)',
      className: 'Kelas',
      revenue: 'Revenue (Rp)'
    };
  });

  const [aiInsights, setAiInsights] = useState<string[]>([]);
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [lastUpdated, setLastUpdated] = useState<string>(new Date().toLocaleTimeString());
  const [selectedSchool, setSelectedSchool] = useState<School | null>(null);

  // Sorting for leaderboard (Derived State - will update automatically when schools state changes)
  const sortedSchools = useMemo(() => [...schools].sort((a, b) => b.revenue - a.revenue), [schools]);
  const topThree = sortedSchools.slice(0, 3);

  // Current Month Display Helper
  const currentPeriod = useMemo(() => {
    return new Intl.DateTimeFormat('id-ID', { month: 'long', year: 'numeric' }).format(new Date());
  }, []);

  const handleUpdateData = (
    newSchools: School[], 
    newStudents: Student[], 
    newDaily?: any[], 
    newWeekly?: any[], 
    newMonthly?: any[],
    newHeaders?: any
  ) => {
    setSchools(newSchools);
    if (newDaily) setDailyData(newDaily);
    if (newWeekly) setWeeklyData(newWeekly);
    if (newMonthly) setMonthlyData(newMonthly);
    if (newHeaders) {
      setHeaderLabels(newHeaders);
      localStorage.setItem('dashboard_header_labels', JSON.stringify(newHeaders));
    }
    
    localStorage.setItem('school_sales_data', JSON.stringify(newSchools));
    setLastUpdated(new Date().toLocaleTimeString());
  };

  const handleSyncUrl = async (url: string) => {
    const data = await fetchGoogleSheetData(url);
    const syncedSchools: School[] = data.map((item: any, idx: number) => {
      return {
        id: String(idx + 1),
        idDigipos: item.IDDigipos || item.id_digipos || item['ID Digipos'] || '',
        name: item.Nama || item.name || item['Nama Sekolah'] || 'Sekolah Baru',
        revenue: Number(item.Revenue || item.revenue || 0),
        prevRevenue: Number(item.PrevRevenue || item.prev_revenue || 0),
        salesCount: Number(item.Sales || item.sales || item.Penjualan || 0),
        lastSale: 'Baru saja',
        trend: (item.Trend || item.trend || 'stable').toLowerCase() as 'up' | 'down' | 'stable',
        region: item.Region || item.region || item.Wilayah || 'Malang',
        topProducts: [],
        totalTransactions: Number(item.Sales || item.sales || item.Penjualan || 0),
        studentCount: Number(item.Siswa || item.StudentCount || item['Total Siswa'] || 0),
        topStudentName: item['Siswa Terbaik'] || item.TopStudent || item.Juara || '-',
        teacherCount: Number(item.Guru || item.TeacherCount || item['Reseller'] || 0),
        topClass: item.Kelas || item.TopClass || item['Kelas Jawara'] || '-',
        topActiveStudents: [], 
        carrierStats: { 
          telkomsel: Number(item.Tsel || 70), 
          indosat: Number(item.Isat || 20), 
          xl: Number(item.XL || 10) 
        },
        dailySales: []
      };
    });
    handleUpdateData(syncedSchools, []);
  };

  const loadInsights = async () => {
    setIsAiLoading(true);
    try {
      const insights = await getDashboardInsights(schools);
      setAiInsights(insights);
    } finally {
      setIsAiLoading(false);
    }
  };

  useEffect(() => {
    if (schools.some(s => s.revenue > 0) && aiInsights.length === 0) {
      loadInsights();
    }
  }, []);

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-[#F7F8FA]">
      {/* Sidebar */}
      <aside className="w-full md:w-20 lg:w-64 bg-[#0F0F0F] text-white p-6 flex flex-col gap-8 hidden md:flex sticky top-0 h-screen border-r border-white/5 shadow-2xl">
        <div className="flex flex-col gap-1 items-center lg:items-start">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-[#EC0000] to-[#800000] rounded-2xl flex items-center justify-center shadow-xl shadow-red-600/20 border border-white/10">
              <Rocket className="w-7 h-7 text-white" />
            </div>
            <div className="hidden lg:block">
              <h1 className="font-black text-2xl tracking-tighter bg-gradient-to-r from-white via-slate-300 to-slate-500 bg-clip-text text-transparent uppercase">
                H.E.R.O
              </h1>
            </div>
          </div>
          <p className="text-[9px] uppercase font-bold text-slate-500 leading-tight mt-6 tracking-[0.15em] hidden lg:block opacity-60">
            Highschool Entrepreneur<br/>Race OSIS
          </p>
        </div>

        <nav className="flex flex-col gap-3 mt-4">
          <button 
            onClick={() => setActiveTab('dashboard')}
            className={`flex items-center gap-4 p-4 rounded-2xl font-bold transition-all duration-300 ${activeTab === 'dashboard' ? 'bg-gradient-to-r from-[#EC0000] to-[#FF4D4D] text-white shadow-lg shadow-red-500/30' : 'text-slate-500 hover:text-white hover:bg-white/5'}`}
          >
            <LayoutDashboard size={20} /> <span className="hidden lg:block text-sm">Race Board</span>
          </button>
          <button 
            onClick={() => setActiveTab('management')}
            className={`flex items-center gap-4 p-4 rounded-2xl font-bold transition-all duration-300 ${activeTab === 'management' ? 'bg-gradient-to-r from-[#EC0000] to-[#FF4D4D] text-white shadow-lg shadow-red-500/30' : 'text-slate-500 hover:text-white hover:bg-white/5'}`}
          >
            <Settings2 size={20} /> <span className="hidden lg:block text-sm">Data Master</span>
          </button>
        </nav>

        <div className="mt-auto hidden lg:block">
          <div className="bg-gradient-to-br from-[#1F1F1F] to-[#0A0A0A] p-5 rounded-[1.5rem] border border-white/5 shadow-2xl relative overflow-hidden">
             <div className="flex items-center gap-2 text-[#FFB800] mb-2">
               <Trophy size={16} />
               <span className="text-[10px] font-black uppercase tracking-[0.15em]">Telkomsel OSIS Race</span>
             </div>
             <p className="text-[11px] text-slate-400 leading-relaxed font-medium">Monitoring Penjualan Sekolah Mitra.</p>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-3 md:p-8 lg:p-12 overflow-y-auto">
        {/* Header */}
        <header className="mb-8 md:mb-12 flex flex-col lg:flex-row justify-between items-center gap-4 md:gap-6">
          <div className="flex items-center gap-4 md:gap-6">
            <h2 className="text-xl md:text-3xl font-black text-slate-900 tracking-tighter uppercase">Race <span className="text-[#EC0000]">Monitoring</span></h2>
            <div className="flex items-center gap-2 md:gap-3 text-[8px] md:text-[10px] font-black text-slate-400 bg-white px-3 md:px-5 py-1.5 md:py-2.5 rounded-xl md:rounded-2xl border border-slate-200 shadow-sm">
              <Clock size={12} className="text-[#EC0000]" /> UPDATE: {lastUpdated}
            </div>
          </div>
          <div className="flex items-center gap-2 md:gap-3">
             <div className="bg-white px-3 md:px-5 py-1.5 md:py-2.5 rounded-xl md:rounded-2xl border border-slate-200 text-[10px] md:text-xs font-bold text-slate-600 shadow-sm flex items-center gap-2">
                <Calendar size={14} className="text-[#FFB800]" /> {currentPeriod}
             </div>
             <button onClick={() => setLastUpdated(new Date().toLocaleTimeString())} className="p-2 md:p-3 bg-white border border-slate-200 text-slate-400 hover:text-[#EC0000] rounded-xl md:rounded-2xl transition-all shadow-sm">
                <RefreshCw size={18} />
             </button>
          </div>
        </header>

        {activeTab === 'dashboard' ? (
          <div className="space-y-10 md:space-y-16 pb-12">
            
            {/* AI Insight Bar */}
            <section className="bg-white border border-slate-200 p-8 rounded-[2.5rem] shadow-sm relative overflow-hidden group">
               <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:opacity-10 transition-opacity">
                  <BrainCircuit size={120} className="text-[#EC0000]" />
               </div>
               <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6 relative z-10">
                  <div className="space-y-4 flex-1">
                     <div className="flex items-center gap-3">
                        <div className="p-2 bg-red-50 text-[#EC0000] rounded-xl">
                           <Sparkles size={20} />
                        </div>
                        <h3 className="text-sm font-black uppercase tracking-widest text-slate-800">Analisis Strategi AI</h3>
                     </div>
                     <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        {isAiLoading ? (
                           <div className="col-span-3 py-4 flex items-center gap-4 animate-pulse">
                              <RefreshCw className="animate-spin text-[#EC0000]" size={20} />
                              <p className="text-xs font-black text-slate-400 uppercase tracking-widest">Memproses Data Penjualan Sekolah...</p>
                           </div>
                        ) : aiInsights.length > 0 ? (
                           aiInsights.map((insight, idx) => (
                              <div key={idx} className="bg-slate-50/50 p-4 rounded-2xl border border-slate-100 flex gap-3">
                                 <div className="w-5 h-5 bg-[#EC0000] text-white rounded-full flex items-center justify-center text-[10px] font-black shrink-0 mt-0.5">{idx + 1}</div>
                                 <p className="text-[11px] leading-relaxed font-bold text-slate-600">{insight}</p>
                              </div>
                           ))
                        ) : (
                           <div className="col-span-3 py-4 flex items-center gap-3 text-slate-400">
                              <AlertCircle size={18} />
                              <p className="text-xs font-black uppercase tracking-widest">Belum ada analisis. Klik Refresh AI untuk memulai.</p>
                           </div>
                        )}
                     </div>
                  </div>
                  <button 
                     onClick={loadInsights}
                     disabled={isAiLoading}
                     className={`flex items-center gap-3 px-8 py-5 rounded-2xl font-black text-[10px] uppercase tracking-widest transition-all ${isAiLoading ? 'bg-slate-100 text-slate-400 cursor-not-allowed' : 'bg-slate-900 text-white hover:bg-black shadow-xl shadow-black/10 hover:scale-105 active:scale-95'}`}
                  >
                     {isAiLoading ? <RefreshCw className="animate-spin" size={16} /> : <BrainCircuit size={16} />}
                     Refresh AI Analysis
                  </button>
               </div>
            </section>
            
            {/* 1. KLASEMEN ATAS (PODIUM) - REALTIME UPDATE */}
            <section>
              <div className="flex items-center justify-between mb-6 md:mb-8">
                <div className="flex items-center gap-2 md:gap-3">
                  <div className="p-2 bg-[#FFB800] text-white rounded-lg md:rounded-xl">
                    <Trophy className="w-4 h-4 md:w-5 md:h-5" />
                  </div>
                  <h3 className="text-[10px] md:text-sm font-black text-slate-800 uppercase tracking-widest italic flex items-center gap-2">
                    Podium Jawara H.E.R.O <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse ml-2"></div>
                  </h3>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-1.5 md:gap-8 items-end px-0.5 md:px-0">
                {/* Silver - Rank 2 */}
                {topThree[1] && (
                  <div 
                    onClick={() => setSelectedSchool(topThree[1])}
                    className="bg-white border-b-2 md:border-b-4 border-slate-300 p-2 md:p-8 rounded-xl md:rounded-[2.5rem] shadow-lg md:shadow-xl hover:-translate-y-2 transition-all cursor-pointer group relative overflow-hidden"
                  >
                    <div className="absolute top-0 right-0 p-2 md:p-6 opacity-5 md:opacity-10 group-hover:opacity-20 transition-opacity">
                      <Trophy className="w-10 h-10 md:w-20 md:h-20 text-slate-400" />
                    </div>
                    <div className="w-6 h-6 md:w-14 md:h-14 bg-slate-100 rounded-lg md:rounded-2xl flex items-center justify-center text-slate-400 font-black text-[10px] md:text-xl mb-2 md:mb-6 border border-slate-200">2</div>
                    <h4 className="text-[8px] md:text-xl font-black text-slate-800 leading-tight mb-1 md:mb-2 uppercase group-hover:text-[#EC0000] transition-colors truncate">{topThree[1].name}</h4>
                    <p className="text-[6px] md:text-xs font-bold text-slate-400 mb-2 md:mb-6 truncate">{topThree[1].region}</p>
                    <div className="pt-2 md:pt-6 border-t border-slate-50 flex justify-between items-end">
                      <div className="flex-1 min-w-0">
                        <p className="text-[5px] md:text-[10px] font-black text-slate-400 uppercase tracking-widest mb-0.5 md:mb-1">Realtime Revenue</p>
                        <p className="text-[8px] md:text-lg font-black text-slate-900 truncate">Rp{topThree[1].revenue.toLocaleString()}</p>
                      </div>
                      <ChevronRight className="w-3 h-3 md:w-5 md:h-5 text-slate-200 group-hover:text-[#EC0000] transform group-hover:translate-x-1 transition-all" />
                    </div>
                  </div>
                )}

                {/* Gold - Rank 1 */}
                {topThree[0] && (
                  <div 
                    onClick={() => setSelectedSchool(topThree[0])}
                    className="bg-gradient-to-br from-[#121212] to-[#000000] p-3 md:p-10 rounded-2xl md:rounded-[3rem] shadow-2xl hover:-translate-y-4 transition-all cursor-pointer group relative overflow-hidden z-10 scale-105 border-b-4 md:border-b-8 border-[#FFB800]"
                  >
                    <div className="absolute top-0 right-0 p-3 md:p-8 text-[#FFB800] opacity-10 md:opacity-20">
                      <Crown className="w-12 h-12 md:w-32 md:h-32" />
                    </div>
                    <div className="w-8 h-8 md:w-16 md:h-16 bg-[#FFB800] rounded-lg md:rounded-2xl flex items-center justify-center text-white font-black text-xs md:text-2xl mb-3 md:mb-8 shadow-lg shadow-yellow-500/30 relative">
                      <Trophy className="w-4 h-4 md:w-8 md:h-8" />
                      <div className="absolute -top-1 -right-1 w-3 h-3 bg-[#EC0000] rounded-full border-2 border-black animate-ping"></div>
                    </div>
                    <h4 className="text-[10px] md:text-2xl font-black text-white leading-tight mb-1 md:mb-3 uppercase tracking-tighter truncate">{topThree[0].name}</h4>
                    <p className="text-[7px] md:text-sm font-bold text-slate-400 mb-3 md:mb-8 truncate">{topThree[0].region}</p>
                    <div className="pt-3 md:pt-8 border-t border-white/10 flex justify-between items-end">
                      <div className="overflow-hidden flex-1">
                        <p className="text-[5px] md:text-[10px] font-black text-[#FFB800] uppercase tracking-widest mb-0.5 md:mb-1">Leader Revenue (Live)</p>
                        <p className="text-[10px] md:text-2xl font-black text-white tracking-tighter truncate">Rp{topThree[0].revenue.toLocaleString()}</p>
                      </div>
                      <div className="bg-[#EC0000] p-1 md:p-3 rounded-md md:rounded-2xl text-white shadow-lg shrink-0 ml-2">
                        <Sparkles className="w-3 h-3 md:w-5 md:h-5" />
                      </div>
                    </div>
                  </div>
                )}

                {/* Bronze - Rank 3 */}
                {topThree[2] && (
                  <div 
                    onClick={() => setSelectedSchool(topThree[2])}
                    className="bg-white border-b-2 md:border-b-4 border-amber-600 p-2 md:p-8 rounded-xl md:rounded-[2.5rem] shadow-lg md:shadow-xl hover:-translate-y-2 transition-all cursor-pointer group relative overflow-hidden"
                  >
                    <div className="absolute top-0 right-0 p-2 md:p-6 opacity-5 md:opacity-10">
                      <Trophy className="w-10 h-10 md:w-20 md:h-20 text-amber-700" />
                    </div>
                    <div className="w-6 h-6 md:w-14 md:h-14 bg-amber-50 rounded-lg md:rounded-2xl flex items-center justify-center text-amber-700 font-black text-[10px] md:text-xl mb-2 md:mb-6 border border-amber-100">3</div>
                    <h4 className="text-[8px] md:text-xl font-black text-slate-800 leading-tight mb-1 md:mb-2 uppercase group-hover:text-[#EC0000] transition-colors truncate">{topThree[2].name}</h4>
                    <p className="text-[6px] md:text-xs font-bold text-slate-400 mb-2 md:mb-6 truncate">{topThree[2].region}</p>
                    <div className="pt-2 md:pt-6 border-t border-slate-50 flex justify-between items-end">
                      <div className="flex-1 min-w-0">
                        <p className="text-[5px] md:text-[10px] font-black text-slate-400 uppercase tracking-widest mb-0.5 md:mb-1">Realtime Revenue</p>
                        <p className="text-[8px] md:text-lg font-black text-slate-900 truncate">Rp{topThree[2].revenue.toLocaleString()}</p>
                      </div>
                      <ChevronRight className="w-3 h-3 md:w-5 md:h-5 text-slate-200 group-hover:text-[#EC0000] transform group-hover:translate-x-1 transition-all" />
                    </div>
                  </div>
                )}
              </div>
            </section>

            {/* 2. TABEL KLASEMEN (FULL WIDTH) */}
            <div className="space-y-8">
              <div className="flex items-center gap-4 mb-2">
                 <div className="p-2.5 bg-slate-900 text-white rounded-xl">
                   <SchoolIcon size={20} />
                 </div>
                 <h3 className="text-sm font-black text-slate-800 uppercase tracking-widest italic">Tabel Klasemen Harian</h3>
              </div>

              <div className="bg-white rounded-[2.5rem] shadow-2xl shadow-slate-200/40 border border-slate-100 overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="bg-slate-50/50 text-slate-400 text-[10px] uppercase font-black tracking-widest border-b border-slate-100">
                        <th className="px-6 md:px-10 py-6 text-center">No</th>
                        <th className="px-6 md:px-10 py-6">Nama Sekolah</th>
                        <th className="px-6 md:px-10 py-6 text-right">Total Omzet</th>
                        <th className="px-6 md:px-10 py-6 text-center">Trend</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {sortedSchools.map((school, index) => (
                        <tr 
                          key={school.id} 
                          onClick={() => setSelectedSchool(school)}
                          className="hover:bg-slate-50 transition-all group cursor-pointer"
                        >
                          <td className="px-6 md:px-10 py-6 text-center">
                            <span className="text-sm font-black text-slate-300 group-hover:text-[#EC0000] transition-colors">{index + 1}</span>
                          </td>
                          <td className="px-6 md:px-10 py-6">
                            <p className="font-black text-slate-800 text-xs md:text-base group-hover:text-[#EC0000] transition-colors uppercase tracking-tighter truncate max-w-[120px] md:max-w-none">{school.name}</p>
                            <p className="text-[8px] text-slate-400 font-bold uppercase">{school.region} • {school.idDigipos}</p>
                          </td>
                          <td className="px-6 md:px-10 py-6 text-right">
                            <p className="font-mono font-black text-slate-900 text-xs md:text-base">Rp{school.revenue.toLocaleString()}</p>
                            <p className="text-[9px] text-[#EC0000] font-black uppercase tracking-widest">{school.salesCount} ITEMS SOLD</p>
                          </td>
                          <td className="px-6 md:px-10 py-6 text-center">
                             {school.trend === 'up' ? (
                               <div className="inline-flex items-center gap-1 text-emerald-600 bg-emerald-50 px-3 py-1 rounded-full text-[10px] font-black border border-emerald-100 uppercase">
                                  <TrendingUp size={12} /> Naik
                               </div>
                             ) : (
                               <div className="inline-flex items-center gap-1 text-slate-400 bg-slate-50 px-3 py-1 rounded-full text-[10px] font-black border border-slate-100 uppercase">
                                  Stable
                               </div>
                             )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <DataManagement 
            schools={schools} 
            students={[]} 
            dailyChart={dailyData}
            weeklyChart={weeklyData}
            monthlyChart={monthlyData}
            headerLabels={headerLabels}
            onUpdate={handleUpdateData}
            onSyncUrl={handleSyncUrl}
          />
        )}
      </main>

      {/* Modal Profile */}
      {selectedSchool && (
        <SchoolDetailModal 
          school={selectedSchool} 
          onClose={() => setSelectedSchool(null)} 
        />
      )}
    </div>
  );
};

export default App;
