
import React from 'react';
import { User, Medal, ArrowRight, Zap } from 'lucide-react';
import { Student } from '../types';

interface StudentLeaderboardProps {
  students: Student[];
}

const StudentLeaderboard: React.FC<StudentLeaderboardProps> = ({ students }) => {
  return (
    <div className="bg-white rounded-[2rem] shadow-xl shadow-slate-200/40 border border-slate-100 overflow-hidden h-full flex flex-col">
      <div className="p-8 border-b border-slate-50 bg-slate-50/50">
        <h2 className="text-xl font-black text-slate-800 flex items-center gap-3">
          <Medal className="text-[#FFB800]" size={24} />
          Top Reseller
        </h2>
        <p className="text-xs font-bold text-slate-400 mt-1">Individual performance terbaik</p>
      </div>
      <div className="p-6 space-y-4 flex-1 overflow-y-auto">
        {students.slice(0, 10).map((student, index) => (
          <div key={student.id} className="group flex items-center gap-5 p-4 rounded-3xl hover:bg-slate-50 transition-all border border-transparent hover:border-slate-100">
            <div className={`w-11 h-11 rounded-2xl flex items-center justify-center font-black text-sm shadow-sm
              ${index === 0 ? 'bg-[#FFB800] text-white shadow-[#FFB800]/20' : 
                index === 1 ? 'bg-[#94A3B8] text-white' :
                index === 2 ? 'bg-[#CD7F32] text-white' : 'bg-slate-100 text-slate-400'}`}>
              {index + 1}
            </div>
            <div className="flex-1">
              <h4 className="font-black text-slate-700 group-hover:text-red-600 transition-colors leading-tight text-sm">{student.name}</h4>
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-tight">{student.schoolName}</p>
            </div>
            <div className="text-right">
              <div className="flex items-center gap-1 justify-end text-slate-800">
                <span className="text-xs font-black">{student.transactions}</span>
                <Zap size={10} className="text-[#EC0000]" />
              </div>
              <p className="text-[10px] font-black text-indigo-600">Rp{student.revenue.toLocaleString()}</p>
            </div>
          </div>
        ))}
      </div>
      <div className="p-6 bg-slate-50/50 border-t border-slate-50">
        <button className="w-full py-4 rounded-2xl bg-white border border-slate-200 text-[10px] font-black uppercase tracking-widest text-slate-400 hover:text-red-600 hover:border-red-100 transition-all flex items-center justify-center gap-2">
          Lihat Semua Peserta <ArrowRight size={14} />
        </button>
      </div>
    </div>
  );
};

export default StudentLeaderboard;
