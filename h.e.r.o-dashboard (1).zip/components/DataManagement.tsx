
import React, { useState, useMemo, useEffect } from 'react';
import { 
  Save, CheckCircle2, AlertCircle, Plus, Trash2, Settings2, 
  Calendar, Filter, Download, Info, GraduationCap, Smartphone, 
  MapPin, Users, Award, MousePointer2, FileText, ArrowRight
} from 'lucide-react';
import { School, Student, Product, SchoolStudent, DailySale, CarrierStats } from '../types';
import { generateEmptyBuyers, generateEmptyProducts } from '../constants';

interface HeaderLabels {
  schoolName: string;
  studentCount: string;
  topStudent: string;
  className: string;
  revenue: string;
}

interface DataManagementProps {
  schools: School[];
  students: Student[];
  dailyChart: any[];
  weeklyChart: any[];
  monthlyChart: any[];
  headerLabels: HeaderLabels;
  onUpdate: (schools: School[], students: Student[], daily?: any[], weekly?: any[], monthly?: any[], headerLabels?: HeaderLabels) => void;
  onSyncUrl: (url: string) => Promise<void>;
}

const DataManagement: React.FC<DataManagementProps> = ({ 
  schools, students, dailyChart, weeklyChart, monthlyChart, headerLabels, onUpdate, onSyncUrl 
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'profile' | 'daily-recap' | 'export-center' | 'top-customers' | 'market'>('profile');
  const [localSchools, setLocalSchools] = useState<School[]>([...schools]);
  const [selectedSchoolIdx, setSelectedSchoolIdx] = useState(0);
  const [status, setStatus] = useState<{type: 'success' | 'error', msg: string} | null>(null);
  const [bulkText, setBulkText] = useState('');
  
  // Date Helper
  const getToday = () => new Date().toLocaleDateString('en-CA');
  const [startDate, setStartDate] = useState<string>(getToday());
  const [endDate, setEndDate] = useState<string>(getToday());

  // Sync back to App.tsx whenever localSchools changes
  const triggerGlobalUpdate = (updatedList: School[]) => {
    onUpdate(updatedList, students, dailyChart, weeklyChart, monthlyChart, headerLabels);
  };

  const normalizeDate = (dateStr: string): string => {
    const trimmed = dateStr.trim();
    if (!trimmed) return getToday();
    if (/^\d{4}-\d{2}-\d{2}$/.test(trimmed)) return trimmed;
    const ddmmyyyy = /^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{2,4})$/;
    const match = trimmed.match(ddmmyyyy);
    if (match) {
      let d = match[1].padStart(2, '0');
      let m = match[2].padStart(2, '0');
      let y = match[3];
      if (y.length === 2) y = `20${y}`;
      return `${y}-${m}-${d}`;
    }
    return trimmed;
  };

  const syncSalesToAggregates = (school: School): School => {
    const sales = school.dailySales || [];
    const totalRev = sales.reduce((acc, s) => acc + s.revenue, 0);
    const totalQty = sales.reduce((acc, s) => acc + s.qty, 0);
    
    // Update top products based on actual sales
    const pMap = new Map<string, number>();
    sales.forEach(s => pMap.set(s.productName, (pMap.get(s.productName) || 0) + s.qty));
    const topP = Array.from(pMap.entries())
      .map(([name, sold]) => ({ name, sold }))
      .sort((a, b) => b.sold - a.sold)
      .slice(0, 5);
    while (topP.length < 5) topP.push({ name: '-', sold: 0 });

    return {
      ...school,
      revenue: totalRev,
      salesCount: totalQty,
      topProducts: topP,
      lastSale: sales.length > 0 ? sales[sales.length - 1].date : '-'
    };
  };

  const handleBulkPaste = () => {
    if (!bulkText.trim()) return;
    try {
      const rows = bulkText.split('\n').filter(r => r.trim());
      const newSales: DailySale[] = rows.map(row => {
        const cols = row.includes('\t') ? row.split('\t') : row.split(',');
        const date = normalizeDate(cols[0] || '');
        const qty = parseInt(cols[5]?.toString().replace(/\D/g, '') || '1');
        const price = parseInt(cols[6]?.toString().replace(/\D/g, '') || '0');
        let rev = parseInt(cols[7]?.toString().replace(/\D/g, '') || '0');
        if (rev === 0) rev = qty * price;

        return {
          id: Math.random().toString(36).substr(2, 9),
          date, idDigipos: cols[1]?.trim() || '', schoolName: cols[2]?.trim() || '',
          msisdn: cols[3]?.trim() || '', customerName: 'Pelanggan', 
          productName: cols[4]?.trim() || 'Paket Data', qty, price, revenue: rev
        };
      });

      const updated = [...localSchools];
      updated[selectedSchoolIdx].dailySales = [...(updated[selectedSchoolIdx].dailySales || []), ...newSales];
      updated[selectedSchoolIdx] = syncSalesToAggregates(updated[selectedSchoolIdx]);
      
      setLocalSchools(updated);
      setBulkText('');
      triggerGlobalUpdate(updated);
      setStatus({ type: 'success', msg: `${newSales.length} Data Berhasil Di-Import!` });
      setTimeout(() => setStatus(null), 3000);
    } catch (e) {
      setStatus({ type: 'error', msg: 'Format Excel Tidak Dikenali.' });
    }
  };

  const handleSchoolUpdate = (field: keyof School, value: any) => {
    const updated = [...localSchools];
    updated[selectedSchoolIdx] = { ...updated[selectedSchoolIdx], [field]: value };
    // If it's the name, also sync back immediately
    setLocalSchools(updated);
    triggerGlobalUpdate(updated);
  };

  const handleRemoveSchool = (idx: number, e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm('Hapus sekolah ini?')) {
      const updated = localSchools.filter((_, i) => i !== idx);
      setLocalSchools(updated);
      setSelectedSchoolIdx(0);
      triggerGlobalUpdate(updated);
    }
  };

  const autoSetRange = () => {
    const sales = localSchools[selectedSchoolIdx]?.dailySales || [];
    if (sales.length === 0) return;
    const sorted = [...sales].sort((a, b) => a.date.localeCompare(b.date));
    setStartDate(sorted[0].date);
    setEndDate(sorted[sorted.length - 1].date);
  };

  const filteredSales = useMemo(() => {
    const sales = localSchools[selectedSchoolIdx]?.dailySales || [];
    return sales.filter(s => s.date >= startDate && s.date <= endDate);
  }, [localSchools, selectedSchoolIdx, startDate, endDate]);

  const rangeTotalRevenue = useMemo(() => {
    return filteredSales.reduce((acc, s) => acc + s.revenue, 0);
  }, [filteredSales]);

  return (
    <div className="space-y-8 pb-20 animate-in fade-in duration-500">
      {/* Top Action Bar */}
      <div className="bg-white p-8 rounded-[2.5rem] border border-slate-200 shadow-sm flex flex-col lg:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-[#EC0000] rounded-2xl text-white shadow-lg shadow-red-500/20">
              <Settings2 size={24} />
            </div>
            <div>
              <h3 className="text-lg font-black text-slate-800 tracking-tight uppercase italic">Admin Race Center</h3>
              <p className="text-sm text-slate-500 font-medium">Pengaturan Data & Monitoring H.E.R.O</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <button onClick={() => {
               onUpdate(localSchools, students, dailyChart, weeklyChart, monthlyChart, headerLabels);
               setStatus({ type: 'success', msg: 'Semua Data Tersinkron!' });
               setTimeout(() => setStatus(null), 3000);
            }} className="bg-[#EC0000] text-white px-10 py-4 rounded-2xl font-black text-xs uppercase tracking-widest hover:scale-105 active:scale-95 transition-all shadow-xl shadow-red-500/20">
              Simpan Permanen
            </button>
          </div>
      </div>

      {status && (
        <div className={`fixed bottom-10 right-10 z-[100] p-5 rounded-2xl flex items-center gap-4 shadow-2xl ${status.type === 'success' ? 'bg-emerald-600 text-white' : 'bg-rose-600 text-white'}`}>
          {status.type === 'success' ? <CheckCircle2 size={24} /> : <AlertCircle size={24} />}
          <span className="font-black text-sm uppercase tracking-tight">{status.msg}</span>
        </div>
      )}

      <div className="bg-white rounded-[3rem] shadow-2xl shadow-slate-200/40 border border-slate-100 overflow-hidden flex flex-col md:flex-row min-h-[850px]">
        {/* Sidebar - List Sekolah Editable */}
        <div className="w-full md:w-80 border-r border-slate-100 bg-slate-50/50 flex flex-col shrink-0">
          <div className="p-8 border-b border-slate-100 flex justify-between items-center bg-white/50">
             <h4 className="text-[10px] font-black uppercase tracking-widest text-slate-400 italic">Daftar Sekolah Peserta</h4>
             <button onClick={() => {
                const newS: School = {
                  id: String(Date.now()), idDigipos: '', name: 'NAMA SEKOLAH BARU',
                  revenue: 0, prevRevenue: 0, salesCount: 0, lastSale: '-', trend: 'stable',
                  region: 'Malang', topProducts: generateEmptyProducts(), totalTransactions: 0,
                  studentCount: 0, topStudentName: '-', teacherCount: 0, topClass: '-',
                  topActiveStudents: generateEmptyBuyers(), carrierStats: { telkomsel: 100, indosat: 0, xl: 0 },
                  dailySales: []
                };
                const newList = [...localSchools, newS];
                setLocalSchools(newList);
                setSelectedSchoolIdx(newList.length - 1);
                triggerGlobalUpdate(newList);
             }} className="p-2 bg-emerald-500 text-white rounded-lg hover:bg-emerald-600 shadow-lg shadow-emerald-500/20">
               <Plus size={16} />
             </button>
          </div>
          <div className="flex-1 overflow-y-auto p-4 space-y-2 no-scrollbar">
            {localSchools.map((school, idx) => (
              <div key={school.id} onClick={() => setSelectedSchoolIdx(idx)} className={`group relative w-full p-4 rounded-2xl transition-all border cursor-pointer ${selectedSchoolIdx === idx ? 'bg-[#EC0000] border-[#EC0000] shadow-xl shadow-red-500/20' : 'bg-white border-slate-100 hover:border-slate-300'}`}>
                <div className="flex items-center gap-3">
                  <span className={`w-6 h-6 rounded-lg flex items-center justify-center text-[10px] font-black ${selectedSchoolIdx === idx ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-400'}`}>{idx + 1}</span>
                  <input 
                    className={`flex-1 bg-transparent font-black text-[11px] uppercase tracking-tighter outline-none border-none p-0 focus:ring-0 ${selectedSchoolIdx === idx ? 'text-white' : 'text-slate-800'}`} 
                    value={school.name} 
                    onChange={(e) => {
                      const updated = [...localSchools];
                      updated[idx].name = e.target.value.toUpperCase();
                      setLocalSchools(updated);
                      triggerGlobalUpdate(updated);
                    }} 
                    onClick={(e) => e.stopPropagation()} 
                  />
                  <button onClick={(e) => handleRemoveSchool(idx, e)} className={`p-1.5 opacity-0 group-hover:opacity-100 transition-opacity ${selectedSchoolIdx === idx ? 'text-white/60 hover:text-white' : 'text-rose-400 hover:text-rose-600'}`}>
                    <Trash2 size={12} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Main Workspace */}
        {localSchools.length > 0 ? (
          <div className="flex-1 flex flex-col bg-[#FDFDFD]">
            <div className="p-8 border-b border-slate-100 bg-white/80 sticky top-0 z-10 flex overflow-x-auto no-scrollbar gap-2">
                {[
                  { id: 'profile', label: 'Profil Sekolah' },
                  { id: 'daily-recap', label: 'Import Penjualan' },
                  { id: 'export-center', label: 'Rekap & Export' },
                  { id: 'top-customers', label: 'Top Customers' },
                  { id: 'market', label: 'Market Share' }
                ].map((tab) => (
                  <button key={tab.id} onClick={() => setActiveSubTab(tab.id as any)} className={`shrink-0 px-8 py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all ${activeSubTab === tab.id ? 'bg-[#EC0000] text-white shadow-lg shadow-red-500/20' : 'bg-slate-100 text-slate-400 hover:bg-slate-200'}`}>
                    {tab.label}
                  </button>
                ))}
            </div>

            <div className="flex-1 p-10 overflow-y-auto">
               
               {/* TAB PROFILE - FULL FORM */}
               {activeSubTab === 'profile' && (
                 <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 animate-in fade-in slide-in-from-bottom-4 duration-500">
                    <div className="space-y-10">
                       <h4 className="text-sm font-black uppercase text-slate-800 tracking-widest flex items-center gap-4 italic"><div className="w-2 h-8 bg-[#EC0000] rounded-full"></div> Identitas & Wilayah</h4>
                       <div className="space-y-6">
                          <div className="space-y-2">
                             <label className="text-[10px] font-black uppercase text-slate-400 ml-2 tracking-widest">Nama Sekolah</label>
                             <div className="relative group">
                                <GraduationCap size={20} className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-[#EC0000] transition-colors" />
                                <input className="w-full bg-white border border-slate-200 rounded-2xl pl-16 pr-6 py-5 font-black text-slate-800 outline-none focus:border-[#EC0000] transition-all shadow-sm" value={localSchools[selectedSchoolIdx].name} onChange={(e) => handleSchoolUpdate('name', e.target.value.toUpperCase())} />
                             </div>
                          </div>
                          <div className="grid grid-cols-2 gap-6">
                            <div className="space-y-2">
                               <label className="text-[10px] font-black uppercase text-slate-400 ml-2">ID Digipos</label>
                               <div className="relative group">
                                  <Smartphone size={20} className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-[#EC0000]" />
                                  <input className="w-full bg-white border border-slate-200 rounded-2xl pl-16 pr-6 py-5 font-black text-slate-800 outline-none focus:border-[#EC0000] transition-all shadow-sm" value={localSchools[selectedSchoolIdx].idDigipos || ''} onChange={(e) => handleSchoolUpdate('idDigipos', e.target.value.toUpperCase())} />
                               </div>
                            </div>
                            <div className="space-y-2">
                               <label className="text-[10px] font-black uppercase text-slate-400 ml-2">Wilayah / Region</label>
                               <div className="relative group">
                                  <MapPin size={20} className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-[#EC0000]" />
                                  <input className="w-full bg-white border border-slate-200 rounded-2xl pl-16 pr-6 py-5 font-black text-slate-800 outline-none focus:border-[#EC0000] transition-all shadow-sm" value={localSchools[selectedSchoolIdx].region || ''} onChange={(e) => handleSchoolUpdate('region', e.target.value)} />
                               </div>
                            </div>
                          </div>
                       </div>
                    </div>

                    <div className="space-y-10">
                       <h4 className="text-sm font-black uppercase text-slate-800 tracking-widest flex items-center gap-4 italic"><div className="w-2 h-8 bg-[#EC0000] rounded-full"></div> Metrik Race</h4>
                       <div className="space-y-6">
                          <div className="grid grid-cols-2 gap-6">
                            <div className="space-y-2">
                               <label className="text-[10px] font-black uppercase text-slate-400 ml-2">Total Siswa</label>
                               <div className="relative group">
                                  <Users size={20} className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-[#EC0000]" />
                                  <input type="number" className="w-full bg-white border border-slate-200 rounded-2xl pl-16 pr-6 py-5 font-black text-slate-800 outline-none focus:border-[#EC0000] transition-all shadow-sm" value={localSchools[selectedSchoolIdx].studentCount} onChange={(e) => handleSchoolUpdate('studentCount', parseInt(e.target.value || '0'))} />
                               </div>
                            </div>
                            <div className="space-y-2">
                               <label className="text-[10px] font-black uppercase text-slate-400 ml-2">Total Reseller (Guru/Siswa)</label>
                               <div className="relative group">
                                  <Users size={20} className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-[#EC0000]" />
                                  <input type="number" className="w-full bg-white border border-slate-200 rounded-2xl pl-16 pr-6 py-5 font-black text-slate-800 outline-none focus:border-[#EC0000] transition-all shadow-sm" value={localSchools[selectedSchoolIdx].teacherCount} onChange={(e) => handleSchoolUpdate('teacherCount', parseInt(e.target.value || '0'))} />
                               </div>
                            </div>
                          </div>
                          <div className="space-y-2">
                             <label className="text-[10px] font-black uppercase text-slate-400 ml-2 tracking-widest">Kelas Jawara Saat Ini</label>
                             <div className="relative group">
                                <Award size={20} className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-[#EC0000]" />
                                <input className="w-full bg-white border border-slate-200 rounded-2xl pl-16 pr-6 py-5 font-black text-slate-800 outline-none focus:border-[#EC0000] transition-all shadow-sm uppercase" value={localSchools[selectedSchoolIdx].topClass || ''} onChange={(e) => handleSchoolUpdate('topClass', e.target.value.toUpperCase())} />
                             </div>
                          </div>
                          <div className="p-8 bg-red-50/50 rounded-3xl border border-red-100 flex flex-col items-center justify-center gap-2">
                             <span className="text-[10px] font-black text-[#EC0000] uppercase tracking-widest">Current Calculated Revenue</span>
                             <p className="text-4xl font-black text-[#EC0000] tracking-tighter">Rp {localSchools[selectedSchoolIdx].revenue.toLocaleString()}</p>
                          </div>
                       </div>
                    </div>
                 </div>
               )}

               {/* TAB DAILY RECAP / IMPORT */}
               {activeSubTab === 'daily-recap' && (
                 <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 animate-in fade-in duration-500">
                    <div className="lg:col-span-5 space-y-6">
                       <div className="bg-slate-900 p-10 rounded-[3rem] text-white shadow-2xl space-y-6">
                          <h4 className="font-black uppercase tracking-widest text-sm italic">Import Data Penjualan</h4>
                          <p className="text-[10px] text-slate-400 leading-relaxed font-medium">Format: Tgl (DD/MM/YYYY), ID Digi, Sekolah, MSISDN, Produk, Qty, Harga, Total.</p>
                          <textarea className="w-full bg-white/5 border border-white/10 rounded-[2rem] p-8 text-xs font-mono min-h-[400px] outline-none focus:border-[#EC0000] transition-all" placeholder="Paste data Excel Anda di sini..." value={bulkText} onChange={(e) => setBulkText(e.target.value)} />
                          <button onClick={handleBulkPaste} className="w-full py-6 bg-[#EC0000] rounded-2xl font-black text-xs uppercase tracking-widest hover:scale-105 active:scale-95 transition-all shadow-xl shadow-red-500/30">Submit Data Transaksi</button>
                       </div>
                    </div>
                    <div className="lg:col-span-7 space-y-6">
                       <div className="flex justify-between items-center px-4">
                          <h5 className="text-[10px] font-black uppercase text-slate-400 tracking-widest">Riwayat Masuk ({localSchools[selectedSchoolIdx].dailySales.length} Item)</h5>
                          <button onClick={() => {
                            if(confirm('Hapus riwayat untuk sekolah ini?')) {
                              const updated = [...localSchools];
                              updated[selectedSchoolIdx].dailySales = [];
                              updated[selectedSchoolIdx].revenue = 0;
                              updated[selectedSchoolIdx].salesCount = 0;
                              setLocalSchools(updated);
                              triggerGlobalUpdate(updated);
                            }
                          }} className="text-rose-500 text-[10px] font-black uppercase hover:underline">Hapus Semua Riwayat</button>
                       </div>
                       <div className="bg-white border rounded-[2.5rem] overflow-hidden shadow-sm max-h-[600px] overflow-y-auto border-slate-100">
                          <table className="w-full text-left">
                             <thead className="sticky top-0 bg-slate-50 border-b z-10">
                                <tr className="text-[9px] uppercase font-black text-slate-400 tracking-widest"><th className="p-6">Tanggal</th><th className="p-6">MSISDN</th><th className="p-6">Produk</th><th className="p-6 text-right">Revenue</th></tr>
                             </thead>
                             <tbody className="divide-y text-[11px] font-bold">
                                {localSchools[selectedSchoolIdx].dailySales.length > 0 ? (
                                  [...localSchools[selectedSchoolIdx].dailySales].reverse().slice(0, 50).map(sale => (
                                    <tr key={sale.id} className="hover:bg-slate-50 transition-colors">
                                      <td className="p-6 text-slate-400">{sale.date}</td>
                                      <td className="p-6 font-black text-slate-800">{sale.msisdn}</td>
                                      <td className="p-6 text-slate-500">{sale.productName}</td>
                                      <td className="p-6 text-right text-[#EC0000]">Rp {sale.revenue.toLocaleString()}</td>
                                    </tr>
                                  ))
                                ) : (
                                  <tr><td colSpan={4} className="py-24 text-center text-slate-300 uppercase font-black tracking-widest">Belum ada data transaksi</td></tr>
                                )}
                             </tbody>
                          </table>
                       </div>
                    </div>
                 </div>
               )}

               {/* TAB EXPORT CENTER / REKAP */}
               {activeSubTab === 'export-center' && (
                 <div className="space-y-12 animate-in fade-in duration-500">
                   <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                      {/* Summary Card */}
                      <div className="bg-slate-900 p-10 rounded-[2.5rem] text-white shadow-2xl flex flex-col justify-between">
                         <div>
                            <h5 className="text-[10px] font-black uppercase text-slate-400 tracking-widest mb-4">Total Life-time Sales</h5>
                            <p className="text-4xl font-black">{localSchools[selectedSchoolIdx].dailySales.length} <span className="text-xs text-slate-500">Sales</span></p>
                            <p className="text-[10px] text-slate-500 mt-4 leading-relaxed font-medium italic">Ini adalah akumulasi seluruh data yang pernah Anda submit untuk sekolah ini.</p>
                         </div>
                         <button onClick={() => {
                            const sales = localSchools[selectedSchoolIdx].dailySales;
                            const headers = ['Tanggal', 'MSISDN', 'Produk', 'Qty', 'Revenue'];
                            const csv = [headers.join(','), ...sales.map(s => [s.date, s.msisdn, s.productName, s.qty, s.revenue].join(','))].join('\n');
                            const blob = new Blob([csv], { type: 'text/csv' });
                            const url = window.URL.createObjectURL(blob);
                            const a = document.createElement('a');
                            a.href = url;
                            a.download = `Rekap_Full_${localSchools[selectedSchoolIdx].name}.csv`;
                            a.click();
                         }} className="mt-8 w-full py-5 bg-white/10 hover:bg-white/20 border border-white/10 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all">Download Full Database</button>
                      </div>

                      {/* Range Filter Card */}
                      <div className="bg-white border border-slate-200 p-10 rounded-[2.5rem] md:col-span-2 shadow-sm flex flex-col lg:flex-row gap-10">
                         <div className="flex-1 space-y-8">
                            <div className="flex justify-between items-center px-2">
                               <h5 className="text-[10px] font-black uppercase text-slate-400 tracking-widest flex items-center gap-2"><Filter size={14} /> Filter Periode Khusus</h5>
                               <button onClick={autoSetRange} className="text-[#EC0000] text-[9px] font-black uppercase flex items-center gap-2 hover:underline">
                                  <MousePointer2 size={12} /> Sinkron Otomatis
                               </button>
                            </div>
                            <div className="grid grid-cols-2 gap-6">
                               <div className="space-y-2">
                                  <label className="text-[9px] font-black uppercase text-slate-400 ml-2">Mulai</label>
                                  <input type="date" className="w-full bg-slate-50 border p-4 rounded-2xl font-black text-xs outline-none focus:border-[#EC0000]" value={startDate} onChange={e => setStartDate(e.target.value)} />
                               </div>
                               <div className="space-y-2">
                                  <label className="text-[9px] font-black uppercase text-slate-400 ml-2">Selesai</label>
                                  <input type="date" className="w-full bg-slate-50 border p-4 rounded-2xl font-black text-xs outline-none focus:border-[#EC0000]" value={endDate} onChange={e => setEndDate(e.target.value)} />
                               </div>
                            </div>
                         </div>
                         <div className="lg:w-1/3 border-t lg:border-t-0 lg:border-l border-slate-100 pt-8 lg:pt-0 lg:pl-12 flex flex-col justify-between">
                            <div>
                               <p className="text-[10px] font-black uppercase text-slate-400 tracking-widest mb-1">Total Omzet Periode:</p>
                               <p className="text-4xl font-black text-[#EC0000] tracking-tighter">Rp {rangeTotalRevenue.toLocaleString()}</p>
                               <p className="text-[10px] font-bold text-slate-400 mt-2">{filteredSales.length} Transaksi Terdeteksi</p>
                            </div>
                            <button onClick={() => {
                               const headers = ['Tanggal', 'MSISDN', 'Produk', 'Qty', 'Revenue'];
                               const csv = [headers.join(','), ...filteredSales.map(s => [s.date, s.msisdn, s.productName, s.qty, s.revenue].join(','))].join('\n');
                               const blob = new Blob([csv], { type: 'text/csv' });
                               const url = window.URL.createObjectURL(blob);
                               const a = document.createElement('a');
                               a.href = url;
                               a.download = `Rekap_${startDate}_to_${endDate}_${localSchools[selectedSchoolIdx].name}.csv`;
                               a.click();
                            }} className="mt-6 w-full py-5 bg-slate-900 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-black transition-all">Download Rekap Periode</button>
                         </div>
                      </div>
                   </div>

                   {/* Preview Table for Range */}
                   <div className="space-y-6">
                      <div className="flex justify-between items-center px-4">
                        <h5 className="text-[10px] font-black uppercase text-slate-500 tracking-widest italic flex items-center gap-3">
                           <FileText size={18} /> Preview Data Filtered: <span className="text-[#EC0000]">{startDate} s/d {endDate}</span>
                        </h5>
                      </div>
                      <div className="bg-white border border-slate-100 rounded-[2.5rem] shadow-sm overflow-hidden">
                        <div className="max-h-[500px] overflow-y-auto no-scrollbar">
                           <table className="w-full text-left">
                              <thead className="bg-slate-50 border-b sticky top-0 z-10 text-[9px] uppercase font-black text-slate-400 tracking-widest">
                                 <tr><th className="px-10 py-6">Tanggal</th><th className="px-10 py-6">MSISDN</th><th className="px-10 py-6">Produk</th><th className="px-10 py-6 text-right">Revenue</th></tr>
                              </thead>
                              <tbody className="divide-y divide-slate-50 text-[11px] font-bold">
                                 {filteredSales.length > 0 ? filteredSales.map(s => (
                                   <tr key={s.id} className="hover:bg-slate-50/80 transition-all">
                                      <td className="px-10 py-5 text-slate-400">{s.date}</td>
                                      <td className="px-10 py-5 font-black text-slate-800">{s.msisdn}</td>
                                      <td className="px-10 py-5 text-slate-500">{s.productName}</td>
                                      <td className="px-10 py-5 text-right text-slate-900">Rp {s.revenue.toLocaleString()}</td>
                                   </tr>
                                 )) : (
                                   <tr><td colSpan={4} className="py-24 text-center text-slate-300 font-black uppercase tracking-widest italic">Tidak ada data dalam periode filter. Gunakan "Sinkron Otomatis".</td></tr>
                                 )}
                              </tbody>
                           </table>
                        </div>
                      </div>
                   </div>
                 </div>
               )}

               {/* TAB TOP CUSTOMERS */}
               {activeSubTab === 'top-customers' && (
                 <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
                    <div className="bg-white border rounded-[3rem] shadow-xl border-slate-100 overflow-hidden">
                      <table className="w-full text-left">
                        <thead className="bg-slate-50 border-b text-[9px] font-black uppercase text-slate-400 tracking-widest">
                           <tr><th className="p-8 text-center w-24">Rank</th><th className="p-8">Nama Customer</th><th className="p-8">MSISDN</th><th className="p-8 text-center">Total Belanja (Unit)</th></tr>
                        </thead>
                        <tbody className="divide-y divide-slate-50 font-black">
                           {localSchools[selectedSchoolIdx].topActiveStudents.map((customer, cIdx) => (
                             <tr key={cIdx} className="hover:bg-slate-50">
                                <td className="p-8 text-center font-black text-slate-300 text-lg">{cIdx + 1}</td>
                                <td className="p-8"><input className="w-full bg-slate-50/50 border border-slate-100 rounded-xl px-4 py-3 font-bold text-xs" value={customer.name} onChange={(e) => {
                                  const updated = [...localSchools];
                                  updated[selectedSchoolIdx].topActiveStudents[cIdx].name = e.target.value;
                                  setLocalSchools(updated);
                                  triggerGlobalUpdate(updated);
                                }} /></td>
                                <td className="p-8"><input className="w-full bg-slate-50/50 border border-slate-100 rounded-xl px-4 py-3 font-mono text-xs" value={customer.phoneNumber} onChange={(e) => {
                                  const updated = [...localSchools];
                                  updated[selectedSchoolIdx].topActiveStudents[cIdx].phoneNumber = e.target.value;
                                  setLocalSchools(updated);
                                  triggerGlobalUpdate(updated);
                                }} /></td>
                                <td className="p-8"><input type="number" className="w-24 mx-auto block bg-slate-50/50 border border-slate-100 rounded-xl px-4 py-3 text-center font-black text-[#EC0000] text-lg" value={customer.transactions} onChange={(e) => {
                                  const updated = [...localSchools];
                                  updated[selectedSchoolIdx].topActiveStudents[cIdx].transactions = parseInt(e.target.value || '0');
                                  setLocalSchools(updated);
                                  triggerGlobalUpdate(updated);
                                }} /></td>
                             </tr>
                           ))}
                        </tbody>
                      </table>
                    </div>
                 </div>
               )}

               {/* TAB MARKET SHARE */}
               {activeSubTab === 'market' && (
                 <div className="grid grid-cols-1 md:grid-cols-3 gap-10 animate-in fade-in slide-in-from-bottom-4 duration-500">
                   {['telkomsel', 'indosat', 'xl'].map(id => (
                     <div key={id} className="bg-white border p-12 rounded-[3rem] shadow-sm border-slate-100 flex flex-col items-center gap-6 group hover:border-[#EC0000] transition-all">
                        <div className={`w-20 h-20 rounded-3xl flex items-center justify-center text-white shadow-xl ${id === 'telkomsel' ? 'bg-[#EC0000] shadow-red-500/20' : id === 'indosat' ? 'bg-amber-500 shadow-amber-500/20' : 'bg-blue-600 shadow-blue-500/20'}`}>
                           <Smartphone size={32} />
                        </div>
                        <h5 className="font-black uppercase tracking-widest text-xs text-slate-400">{id} Share %</h5>
                        <input type="number" className="w-full bg-slate-50 border border-slate-100 rounded-3xl px-4 py-8 text-center font-black text-5xl outline-none focus:bg-white focus:border-[#EC0000] transition-all tracking-tighter" value={localSchools[selectedSchoolIdx].carrierStats[id as keyof CarrierStats]} onChange={(e) => {
                           const updated = [...localSchools];
                           updated[selectedSchoolIdx].carrierStats = { ...updated[selectedSchoolIdx].carrierStats, [id]: parseInt(e.target.value || '0') };
                           setLocalSchools(updated);
                           triggerGlobalUpdate(updated);
                        }} />
                     </div>
                   ))}
                 </div>
               )}
            </div>
          </div>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center bg-slate-50 gap-6">
             <Info size={64} className="text-slate-200" />
             <p className="text-slate-400 font-black uppercase tracking-widest text-sm">Belum Ada Sekolah Yang Terdaftar</p>
             <button onClick={() => {/* logic add */}} className="px-8 py-4 bg-[#EC0000] text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl">Tambah Sekolah Pertama</button>
          </div>
        )}
      </div>
    </div>
  );
};

export default DataManagement;
