
import React from 'react';
import { X, TrendingUp, Users, GraduationCap, Phone, Signal, Award, ShoppingCart, Radio, Globe, Package, Zap } from 'lucide-react';
import { School } from '../types';

interface SchoolDetailModalProps {
  school: School;
  onClose: () => void;
}

const SchoolDetailModal: React.FC<SchoolDetailModalProps> = ({ school, onClose }) => {
  const sortedProducts = [...school.topProducts].sort((a, b) => b.sold - a.sold).slice(0, 5);
  const maxSold = sortedProducts[0]?.sold || 1;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="bg-white rounded-[3rem] w-full max-w-5xl max-h-[90vh] shadow-[0_35px_60px_-15px_rgba(0,0,0,0.5)] overflow-hidden animate-in fade-in zoom-in duration-300 flex flex-col border border-slate-100">
        {/* Header Section */}
        <div className="bg-[#0F0F0F] p-10 flex justify-between items-start sticky top-0 z-10 text-white border-b border-white/5">
          <div className="flex gap-8 items-center">
            <div className="w-24 h-24 bg-gradient-to-br from-[#EC0000] to-[#800000] rounded-[2rem] flex items-center justify-center text-white shadow-2xl">
               <GraduationCap size={48} />
            </div>
            <div>
              <div className="flex items-center gap-5 mb-2">
                <h2 className="text-4xl font-black tracking-tighter leading-none">{school.name}</h2>
                <span className="bg-[#EC0000] text-white text-[10px] font-black px-4 py-2 rounded-2xl uppercase tracking-widest border border-white/10">
                  {school.region}
                </span>
              </div>
              <p className="text-slate-400 font-bold flex items-center gap-3 text-sm tracking-wide">
                <Radio size={18} className="text-[#EC0000]" /> Highschool Entrepreneur Race Osis • ID Digipos: {school.idDigipos || '-'}
              </p>
            </div>
          </div>
          <button onClick={onClose} className="p-4 bg-white/5 hover:bg-white/10 rounded-3xl transition-all text-white border border-white/10">
            <X size={28} />
          </button>
        </div>
        
        <div className="flex-1 overflow-y-auto p-12 space-y-16 bg-[#FBFBFB]">
          {/* Main Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
             <div className="bg-white border border-slate-100 p-8 rounded-[2rem] shadow-sm">
                <div className="flex items-center gap-4 text-slate-400 mb-5">
                  <Users size={24} className="text-[#4F46E5]" />
                  <span className="text-[10px] font-black uppercase tracking-widest">Jumlah Siswa</span>
                </div>
                <p className="text-3xl font-black text-slate-800 tracking-tighter">
                  {school.studentCount.toLocaleString()}
                </p>
             </div>
             <div className="bg-red-50/50 border border-red-100 p-8 rounded-[2rem]">
                <div className="flex items-center gap-4 text-[#EC0000] mb-5">
                  <Award size={24} />
                  <span className="text-[10px] font-black uppercase tracking-widest">Kelas Jawara</span>
                </div>
                <p className="text-2xl font-black text-[#EC0000] tracking-tighter uppercase">{school.topClass}</p>
             </div>
             <div className="bg-slate-900 border border-slate-800 p-8 rounded-[2rem] text-white shadow-2xl">
                <div className="flex items-center gap-4 text-slate-500 mb-5">
                  <Package size={24} className="text-[#10B981]" />
                  <span className="text-[10px] font-black uppercase tracking-widest">Total Qty Sales</span>
                </div>
                <p className="text-4xl font-black text-white tracking-tighter">{school.salesCount.toLocaleString()}</p>
             </div>
             <div className="bg-emerald-50 border border-emerald-100 p-8 rounded-[2rem]">
                <div className="flex items-center gap-4 text-emerald-600 mb-5">
                  <TrendingUp size={24} />
                  <span className="text-[10px] font-black uppercase tracking-widest">Total Revenue</span>
                </div>
                <p className="text-2xl font-black text-emerald-700 tracking-tighter">Rp{school.revenue.toLocaleString()}</p>
             </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
            {/* Products & Market Share */}
            <div className="lg:col-span-5 space-y-12">
              {/* Products */}
              <div className="space-y-8">
                <div className="flex items-center gap-4">
                  <div className="p-3 bg-red-50 rounded-2xl text-[#EC0000]">
                    <ShoppingCart size={24} />
                  </div>
                  <h3 className="text-base font-black text-slate-800 uppercase tracking-widest">5 Produk Sering Dibeli</h3>
                </div>
                <div className="bg-white border border-slate-100 p-10 rounded-[2.5rem] shadow-sm space-y-8">
                  {sortedProducts.map((product, i) => (
                    <div key={i} className="space-y-3">
                      <div className="flex justify-between items-end">
                        <span className="text-sm font-bold text-slate-700">{product.name}</span>
                        <span className="text-[11px] font-black text-[#EC0000]">{product.sold} Unit</span>
                      </div>
                      <div className="w-full bg-slate-50 h-3 rounded-full overflow-hidden">
                        <div 
                          className="bg-[#EC0000] h-full rounded-full transition-all duration-1000" 
                          style={{ width: `${(product.sold / maxSold) * 100}%` }}
                        ></div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Market Share */}
              <div className="space-y-8">
                <div className="flex items-center gap-4">
                  <div className="p-3 bg-indigo-50 rounded-2xl text-indigo-600">
                    <Globe size={24} />
                  </div>
                  <h3 className="text-base font-black text-slate-800 uppercase tracking-widest">Market Share Kompetitor</h3>
                </div>
                <div className="bg-white border border-slate-100 p-10 rounded-[2.5rem] shadow-sm space-y-6">
                   {[
                     { name: 'Telkomsel', val: school.carrierStats.telkomsel, color: '#EC0000' },
                     { name: 'Indosat', val: school.carrierStats.indosat, color: '#F59E0B' },
                     { name: 'XL Axiata', val: school.carrierStats.xl, color: '#2563EB' }
                   ].map(c => (
                     <div key={c.name} className="space-y-2">
                        <div className="flex justify-between text-[10px] font-black uppercase">
                           <span className="text-slate-500">{c.name}</span>
                           <span style={{ color: c.color }}>{c.val}%</span>
                        </div>
                        <div className="w-full bg-slate-50 h-3 rounded-full overflow-hidden">
                           <div style={{ backgroundColor: c.color, width: `${c.val}%` }} className="h-full"></div>
                        </div>
                     </div>
                   ))}
                </div>
              </div>
            </div>

            {/* Top 10 Customers */}
            <div className="lg:col-span-7 space-y-8">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-emerald-50 rounded-2xl text-emerald-600">
                  <Users size={24} />
                </div>
                <h3 className="text-base font-black text-slate-800 uppercase tracking-widest">Top 10 Customers</h3>
              </div>

              <div className="bg-white border border-slate-100 rounded-[2.5rem] shadow-xl overflow-hidden">
                <table className="w-full text-left border-collapse">
                   <thead>
                      <tr className="bg-slate-50/50 text-[10px] uppercase font-black tracking-[0.2em] text-slate-400 border-b border-slate-100">
                         <th className="px-8 py-6">Nama & Kelas</th>
                         <th className="px-8 py-6">No. HP</th>
                         <th className="px-8 py-6 text-right">Qty Beli</th>
                      </tr>
                   </thead>
                   <tbody className="divide-y divide-slate-50">
                      {school.topActiveStudents.slice(0, 10).map((student, i) => (
                        <tr key={i} className="hover:bg-slate-50/80 transition-all group">
                           <td className="px-8 py-6">
                              <div className="flex flex-col">
                                <span className="font-black text-slate-800 group-hover:text-[#EC0000] transition-colors">{student.name}</span>
                                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">{student.className}</span>
                              </div>
                           </td>
                           <td className="px-8 py-6 text-xs font-mono font-bold text-slate-400">
                              {student.phoneNumber}
                           </td>
                           <td className="px-8 py-6 text-right">
                              <div className="flex items-center justify-end gap-2">
                                <span className="text-base font-mono font-black text-slate-900 group-hover:text-[#EC0000] transition-colors">
                                  {student.transactions}
                                </span>
                                <div className="flex flex-col items-start leading-none">
                                  <span className="text-[9px] font-black text-slate-300 uppercase">Unit</span>
                                  <Zap size={10} className="text-[#EC0000] mt-0.5 opacity-0 group-hover:opacity-100 transition-opacity" />
                                </div>
                              </div>
                           </td>
                        </tr>
                      ))}
                   </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-10 bg-white border-t border-slate-100 flex justify-end gap-5 sticky bottom-0 z-10">
           <button onClick={onClose} className="px-12 py-5 bg-slate-100 text-slate-500 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-slate-200 transition-all">
             Kembali ke Race Board
           </button>
           <button className="px-12 py-5 bg-[#EC0000] text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-2xl shadow-red-200">
             Unduh Raport Sekolah
           </button>
        </div>
      </div>
    </div>
  );
};

export default SchoolDetailModal;
