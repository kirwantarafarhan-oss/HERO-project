
import React from 'react';
import { ArrowUpRight, ArrowDownRight } from 'lucide-react';

interface StatCardProps {
  title: string;
  value: string;
  icon: React.ReactNode;
  color: string;
  comparison?: {
    value: number;
    isPositive: boolean;
  };
}

const StatCard: React.FC<StatCardProps> = ({ title, value, icon, color, comparison }) => {
  return (
    <div className="bg-white p-6 rounded-[2rem] shadow-xl shadow-slate-200/40 border border-slate-100 flex flex-col gap-4 transition-all duration-300 hover:-translate-y-1 hover:border-red-100 group">
      <div className="flex justify-between items-start">
        <div className={`${color} p-4 rounded-2xl text-white shadow-xl shadow-slate-400/10 group-hover:scale-110 transition-transform duration-300`}>
          {icon}
        </div>
        {comparison && (
          <div className={`flex items-center gap-1 text-[11px] font-black px-3 py-1.5 rounded-full border ${comparison.isPositive ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 'bg-rose-50 text-rose-600 border-rose-100'}`}>
            {comparison.isPositive ? <ArrowUpRight size={14} /> : <ArrowDownRight size={14} />}
            {comparison.value}%
          </div>
        )}
      </div>
      <div className="mt-2">
        <p className="text-[10px] text-slate-400 font-black uppercase tracking-[0.15em] mb-1">{title}</p>
        <h3 className="text-2xl font-black text-slate-800 tracking-tighter leading-none">{value}</h3>
      </div>
    </div>
  );
};

export default StatCard;
