
import React from 'react';
import { School } from '../types';
import { ExternalLink, TrendingUp, TrendingDown, Minus, Crown } from 'lucide-react';

interface LeaderboardProps {
  schools: School[];
  onSchoolClick?: (school: School) => void;
}

const Leaderboard: React.FC<LeaderboardProps> = ({ schools, onSchoolClick }) => {
  const sortedSchools = [...schools].sort((a, b) => b.revenue - a.revenue);
  const maxRevenue = sortedSchools[0]?.revenue || 1;

  return (
    <div className="bg-white rounded-[2rem] shadow-xl shadow-slate-200/40 border border-slate-100 overflow-hidden">
      <div className="p-8 border-b border-slate-50 flex justify-between items-center bg-slate-50/50">
        <div>
          <h2 className="text-xl font-black text-slate-800 flex items-center gap-3">
            Klasemen H.E.R.O <span className="text-[#EC0000] px-3 py-1 bg-red-50 rounded-xl text-sm">Season 1</span>
          </h2>
          <p className="text-xs font-bold text-slate-400 mt-1">Peringkat berdasarkan total omzet sekolah</p>
        </div>
        <div className="flex gap-2">
           <span className="flex items-center gap-2 text-[10px] font-black bg-slate-900 text-white px-4 py-2 rounded-2xl tracking-widest uppercase shadow-lg shadow-black/10">
             <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div> Live Stats
           </span>
        </div>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-50/30 text-slate-400 text-[10px] uppercase font-black tracking-widest">
              <th className="px-8 py-5 text-center">Rank</th>
              <th className="px-8 py-5">Sekolah Peserta</th>
              <th className="px-8 py-5">Wilayah</th>
              <th className="px-8 py-5 text-right">Revenue</th>
              <th className="px-8 py-5 text-center">Status</th>
              <th className="px-8 py-5"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {sortedSchools.map((school, index) => {
              const rank = index + 1;
              const intensity = (school.revenue / maxRevenue);
              
              return (
                <tr 
                  key={school.id} 
                  onClick={() => onSchoolClick?.(school)}
                  className="hover:bg-slate-50 transition-all group cursor-pointer"
                >
                  <td className="px-8 py-6 text-center">
                    <div className="flex justify-center">
                      <span className={`flex items-center justify-center w-9 h-9 rounded-xl font-black text-sm shadow-sm
                        ${rank === 1 ? 'bg-[#FFB800] text-white shadow-[#FFB800]/20' : 
                          rank === 2 ? 'bg-[#94A3B8] text-white shadow-slate-400/20' :
                          rank === 3 ? 'bg-[#CD7F32] text-white shadow-amber-700/20' : 'bg-slate-100 text-slate-500'}`}>
                        {rank === 1 ? <Crown size={18} /> : rank}
                      </span>
                    </div>
                  </td>
                  <td className="px-8 py-6">
                    <p className="font-black text-slate-800 text-base group-hover:text-red-600 transition-colors">{school.name}</p>
                    <p className="text-[10px] text-slate-400 font-bold tracking-tight mt-0.5">Partner ID: {school.id.padStart(4, '0')}</p>
                  </td>
                  <td className="px-8 py-6">
                    <span className="text-[10px] font-black text-slate-600 bg-slate-100 px-3 py-1.5 rounded-xl border border-slate-200 uppercase tracking-tighter">
                      {school.region}
                    </span>
                  </td>
                  <td className="px-8 py-6 text-right">
                    <p className="font-mono font-black text-slate-900 text-base">Rp{school.revenue.toLocaleString()}</p>
                    <p className="text-[10px] text-red-500 font-black uppercase tracking-widest">{school.salesCount} Sales</p>
                  </td>
                  <td className="px-8 py-6 text-center">
                    <div className="flex justify-center scale-110">
                      {school.trend === 'up' && <div className="bg-emerald-50 p-2 rounded-xl text-emerald-500 border border-emerald-100"><TrendingUp size={16} /></div>}
                      {school.trend === 'down' && <div className="bg-rose-50 p-2 rounded-xl text-rose-500 border border-rose-100"><TrendingDown size={16} /></div>}
                      {school.trend === 'stable' && <div className="bg-slate-50 p-2 rounded-xl text-slate-300 border border-slate-100"><Minus size={16} /></div>}
                    </div>
                  </td>
                  <td className="px-8 py-6 text-slate-200 group-hover:text-red-600 transition-all transform group-hover:translate-x-1">
                    <ExternalLink size={18} />
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Leaderboard;
