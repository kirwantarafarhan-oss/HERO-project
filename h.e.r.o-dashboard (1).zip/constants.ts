
import { School, SchoolStudent, Product, Student, DailySale } from './types';

export const generateEmptyBuyers = (): SchoolStudent[] => 
  Array.from({ length: 10 }, () => ({
    name: '-',
    phoneNumber: '-',
    className: '-',
    transactions: 0
  }));

export const generateEmptyProducts = (): Product[] => 
  Array.from({ length: 5 }, () => ({
    name: '-',
    sold: 0
  }));

const schoolNames = [
  'SMKN 1 KEPANJEN',
  'SMKN 13 MALANG',
  'SMAN 6 MALANG',
  'SMKN 1 PUJON',
  'SMKN 8 MALANG',
  'SMKN 6 MALANG',
  'SMAN 1 LAWANG',
  'SMAN 9 MALANG',
  'SMKN 4 MALANG',
  'SMAN 1 MALANG',
  'SMKN 5 MALANG',
  'SMKN 12 MALANG'
];

export const SCHOOLS_DATA: School[] = schoolNames.map((name, idx) => ({
  id: String(idx + 1),
  idDigipos: `DIGI-${8000 + idx}`,
  name: name,
  revenue: 0, // Mulai dari 0
  prevRevenue: 0,
  salesCount: 0, // Mulai dari 0
  lastSale: '-',
  trend: 'stable',
  region: idx % 2 === 0 ? 'Kab. Malang' : 'Kota Malang',
  topProducts: generateEmptyProducts(),
  totalTransactions: 0,
  studentCount: 0,
  topStudentName: '-',
  teacherCount: 0,
  topClass: '-',
  carrierStats: { telkomsel: 100, indosat: 0, xl: 0 },
  topActiveStudents: generateEmptyBuyers(),
  dailySales: [] // Riwayat transaksi kosong
}));

export const TOP_STUDENTS: Student[] = [];

export const DAILY_CHART = [
  { name: 'Sen', revenue: 0 }, { name: 'Sel', revenue: 0 }, { name: 'Rab', revenue: 0 },
  { name: 'Kam', revenue: 0 }, { name: 'Jum', revenue: 0 }, { name: 'Sab', revenue: 0 }, { name: 'Min', revenue: 0 },
];

export const WEEKLY_CHART = [
  { name: 'Minggu 1', revenue: 0 }, { name: 'Minggu 2', revenue: 0 }, { name: 'Minggu 3', revenue: 0 },
  { name: 'Minggu 4', revenue: 0 }, { name: 'Minggu 5', revenue: 0 },
];

export const MONTHLY_CHART = [
  { name: 'Jan', revenue: 0 }, { name: 'Feb', revenue: 0 }, { name: 'Mar', revenue: 0 },
  { name: 'Apr', revenue: 0 }, { name: 'Mei', revenue: 0 },
];
